function [jieta] = sol_jieta(mp)
jieta = sqrt(1/(1/((log(mp/100)/pi)^2)+1));