function [E] = SF(K,a,b,c,u,x)
E =a*x + b*u;
