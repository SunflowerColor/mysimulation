function [wn] = sol_wn(ts,jieta)
wn =4/(jieta *ts);