load y_tt
plot(y)